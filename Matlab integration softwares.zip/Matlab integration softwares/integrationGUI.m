function varargout = integrationGUI(varargin)
% INTEGRATIONGUI MATLAB code for integrationGUI.fig
%      INTEGRATIONGUI, by itself, creates a new INTEGRATIONGUI or raises the existing
%      singleton*.
%
%      H = INTEGRATIONGUI returns the handle to a new INTEGRATIONGUI or the handle to
%      the existing singleton*.
%
%      INTEGRATIONGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in INTEGRATIONGUI.M with the given input arguments.
%
%      INTEGRATIONGUI('Property','Value',...) creates a new INTEGRATIONGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before integrationGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to integrationGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help integrationGUI

% Last Modified by GUIDE v2.5 10-Nov-2016 01:35:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @integrationGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @integrationGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT



% --- Executes just before integrationGUI is made visible.
function integrationGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to integrationGUI (see VARARGIN)

[FileName,PathName] = uigetfile('*.xls*'); %asks for file
num = xlsread(strcat(PathName,FileName),'A:B'); %read it in
%num = xlsread('C:\Users\Valentin\Desktop\New folder\SRS3.xlsx','A:B'); %
%for debugging
handles.PathName=PathName;
handles.num=num;
handles.peak=1;
axes(handles.axes1)
plot(num(:,2),num(:,1)); %draws initial plot

% 
axes(handles.axes2)
cla;
plot(num(:,2),num(:,1)); %draw second plot
handles.Data=[0 0 0]; %creates initial datafile
handles.peakData=[0 0]; %initialize
set(handles.text1,'String','Press Next peak button'); %adds name
% Choose default command line output for integrationGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes integrationGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = integrationGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Exit.
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% save if name is given
methodname=handles.methodname; %gets name
PathName=handles.PathName;
peakData=handles.peakData;
Data=handles.Data;
if strcmp(get(methodname,'String'),'File to save method')
else
    %saves out results
    xlswrite(strcat(PathName,get(methodname,'String'),'.xlsx'),[{'Peak Area'} {'Concetration'} {'Calibration'} {'Peak start'} {'Peak end'}],'A1:E1');
no=size(Data,1);
    xlswrite(strcat(PathName,get(methodname,'String'),'.xlsx'),[Data peakData],strcat('A2:E',num2str(1+no)));

    axes(handles.axes2)
 print -dmeta;   %.................Copying to clipboard

   FILE  = strcat(PathName,get(methodname,'String'),'.xlsx');
   Range ='G3';
   %.............excel COM object............................................................................
         Excel = actxserver ('Excel.Application');
 Excel.Visible = 1;

 if ~exist(FILE,'file')
       ExcelWorkbook=Excel.Workbooks.Add;
       ExcelWorkbook.SaveAs(FILE);
       ExcelWorkbook.Close(false);
 end
 invoke(Excel.Workbooks,'Open',FILE); %Open the file
 ActiveSheet  = Excel.ActiveSheet;
 ActiveSheetRange  = get(ActiveSheet,'Range',Range);
 ActiveSheetRange.Select;
 ActiveSheetRange.PasteSpecial; %.................Pasting the figure to the selected location
end

close all force



% --- Executes during object creation, after setting all properties.
function methodname_CreateFcn(hObject, eventdata, handles)
% hObject    handle to methodname (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes during object creation, after setting all properties.
function text1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uitable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uitable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

function methodname_Callback(hObject, eventdata, handles)
% hObject    handle to Nextpeak (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB


% --- Executes on button press in Nextpeak.
function Nextpeak_Callback(hObject, eventdata, handles)
% hObject    handle to Nextpeak (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%start peak find
    peak=handles.peak; %access values between callbacks
    num=handles.num;
    peakData=handles.peakData;
for i=1:2
%hold on
datacursormode on %adds cursor
    if i==1
    set(handles.text1,'String',strcat('Choose ',num2str(peak), ' peak left side'))
    else
    set(handles.text1,'String',strcat('Choose ',num2str(peak), ' peak right side'))    
    end
peakboundaries(peak,i,:) = ginput(1); %waits for boundaries
end
  set(handles.text1,'String',strcat('Next peak?'));    
  
%find the peak between two boundaries
[valleys,locsv]=findpeaks(-num(:,1)); %all the valleys in dtaset
indexstart=find(num(:,2)>peakboundaries(peak,1,1),1,'first'); %gets position of first datapoint 
indexend=find(num(:,2)>peakboundaries(peak,2,1),1,'first'); % position of mast datapoint

[peaks,locs]=findpeaks(num(indexstart:indexend), 'SORTSTR','descend'); % the peak inbetween boundearies in descending order

leftside=locsv(find(locsv<(locs(1)+indexstart),1,'last')); %finds first valley before peak
rightside=locsv(find(locsv>(locs(1)+indexstart),1,'first')); %finds last valley after peak
%integrate
base=polyfit([num(leftside,2)  num(rightside,2)],[num(leftside,1)  num(rightside,1)],1); %fit linear between rigth and left side valleys
%first is slope, second intersection

%numerical integration
%integrates area and subtracts baseline
peakarea=trapz(num(leftside:rightside,2),num(leftside:rightside,1))-trapz([num(leftside,2) num(rightside,2) ],[num(leftside,1) num(rightside,1)]);
peakData(peak,:)=[num(leftside,2) num(rightside,2)];
handles.peakData=peakData;
%write values, updata Data
Data=handles.Data;
Data(peak,:)=[peakarea 0 0];
set(handles.uitable,'Data',Data);
handles.Data=Data;
line=num(leftside:rightside,2)*base(1)+base(2);
%plot peakfind
axes(handles.axes2)
hold on
hline=plot(num(leftside:rightside,2),line,'Color',[1 0 0],'LineWidth',2);
text(num(leftside,2),min(num(leftside:rightside,1)),num2str(peak));
handles.hline=hline;
handles.peak=peak+1;           
 guidata(hObject, handles);           

            


% --- Executes when entered data in editable cell(s) in uitable.
function uitable_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitable (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
Indices=eventdata.Indices; %gets place of change
NewData=eventdata.NewData; %gets value of change
Data=handles.Data;
Data(Indices(1),2)=Data(Indices(1),1)/NewData; %calculates conc
Data(Indices(1),3)=NewData; %saves the slope
handles.Data=Data; 
set(handles.uitable,'Data',Data); %write it to table
guidata(hObject, handles); %updates changes

function uitable_DeleteFcn(varargin)



