[FileName,PathName] = uigetfile('*.xls*'); %choose methodfile
num = xlsread(strcat(PathName,FileName)); %read in method file
peakboundaries=num(:,4:5); %copy boundaries
calib=num(:,3);
cd(PathName); %change active folder
files=dir('*.xls*'); %list files

%% Read in only measurement files
clear datafile
counter=1;
for i=1:length(files)
    buffer=xlsread(files(i).name);
    if size(buffer,2)==5
    else 
        datafile{counter}=buffer;
        datafilename{counter}=files(i).name;
        counter=counter+1;
    end
    clear buffer;
end

%% Integrate between boundaries, plot

for ii=1:length(datafile) %every file
display(datafilename(ii)) %write in command window which file is processed
    figure('Name',datafilename{ii},'NumberTitle','off')
data=datafile{ii};
plot(data(:,2),data(:,1));
hold on
    for jj=1:length(peakboundaries) %every peak
        
        [valleys,locsv]=findpeaks(-data(:,1)); %all the valleys in dtaset
        indexstart=find(data(:,2)>peakboundaries(jj,1),1,'first'); 
        indexend=find(data(:,2)>peakboundaries(jj,2),1,'first');
        %find peak
        [peaks,locs]=findpeaks(data(indexstart:indexend), 'SORTSTR','descend'); % the peak inbetween boundearies in descending order
        %locate two sides
        leftside=locsv(find(locsv<(locs(1)+indexstart),1,'last'));
        rightside=locsv(find(locsv>(locs(1)+indexstart),1,'first'));
        %integrate
        base=polyfit([data(leftside,2)  data(rightside,2)],[data(leftside,1)  data(rightside,1)],1);
        peakarea=trapz(data(leftside:rightside,1),data(leftside:rightside,2))-trapz([data(leftside,1) data(rightside,1) ],[data(leftside,1) data(rightside,1)]);
        
        %write values
        % area conc calib left right
        peakData(jj,:)=[peakarea 0 calib(jj) data(leftside,2) data(rightside,2)];
        if calib jj~=0
            peakData(jj,2)=peakData(jj,1)/peakData(jj,3);
        end
        %plot baseline
        line=data(leftside:rightside,2)*base(1)+base(2);
        hline=plot(data(leftside:rightside,2),line,'Color',[1 0 0],'LineWidth',2);
        hold on
        text(data(leftside,2),min(data(leftside:rightside,1)),num2str(jj));

    end
    %Save to excel
      %values
    xlswrite(strcat(PathName,'Results_',datafilename{ii}),[{'Peak Area'} {'Concetration'} {'Calibration'} {'Peak start'} {'Peak end'}],'A1:E1');
no=size(peakboundaries,1);
    xlswrite(strcat(PathName,'Results_',datafilename{ii}),peakData,strcat('A2:E',num2str(1+no)));
      %plot
 print -dmeta;   %.................Copying to clipboard

   FILE  = strcat(PathName,'Results_',datafilename{ii});
   Range ='G3';
   %.............excel COM object............................................................................
         Excel = actxserver ('Excel.Application');
 Excel.Visible = 1;

 if ~exist(FILE,'file')
       ExcelWorkbook=Excel.Workbooks.Add;
       ExcelWorkbook.SaveAs(FILE);
       ExcelWorkbook.Close(false);
 end
 invoke(Excel.Workbooks,'Open',FILE); %Open the file
 ActiveSheet  = Excel.ActiveSheet;
 ActiveSheetRange  = get(ActiveSheet,'Range',Range);
 ActiveSheetRange.Select;
 ActiveSheetRange.PasteSpecial; %.................Pasting the figure to the selected location
Excel.ActiveWorkbook.Save;
    
clear data    
end
%kill excell
system('taskkill /F /IM EXCEL.EXE');

